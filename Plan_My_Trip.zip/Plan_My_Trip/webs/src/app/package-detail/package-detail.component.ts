
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

@Component({
   selector: 'app-package-detail',
   templateUrl: './package-detail.component.html',
   styleUrls: ['./package-detail.component.css']
 })
export class PackageDetailComponent implements OnInit{
   displayedColumns: string[] = ['name', 'Noduring', 'costa', 'costb','costc'];
   dataSource = new MatTableDataSource<PackageDetail>(ELEMENT_DATA);
 
   @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
 
   ngOnInit() {
     this.dataSource.paginator = this.paginator;
   }
 }
 export interface PackageDetail {
   Noduring: number;
  name:string;
   costa: number;
   costb: number;
   costc: number;
}
   const ELEMENT_DATA : PackageDetail[] = [
       {name: 'us', Noduring:1, costa:10000, costb: 10200, costc:10400},
       {name: 'uk', Noduring:2, costa:10200, costb: 10500, costc:10600},
       {name: 'us', Noduring:3, costa:10300, costb: 10600, costc:11200},
       {name: 'uk', Noduring:4, costa:10400, costb: 10800, costc:11200},
       {name: 'us', Noduring:5, costa:10600, costb: 11200, costc:11400},
       {name: 'uk', Noduring:6, costa:10800, costb: 11400, costc:11800},
       {name: 'us', Noduring:7, costa:11000, costb: 11200, costc:12000},
    ];
    /*displayedColumns: string[] = ['packagename', 'Noduring', 'costa', 'costb','costc'];
  }*/
