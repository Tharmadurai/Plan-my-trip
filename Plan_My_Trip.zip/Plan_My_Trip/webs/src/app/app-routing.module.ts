import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { SpecialComponent } from './special/special.component';
import { DestinationComponent } from './destination/destination.component';
import { PackageComponent } from './package/package.component';
import { BlogComponent } from './blog/blog.component';
import { SubscriptionComponent } from './subscription/subscription.component';
import { TestmonialComponent } from './testmonial/testmonial.component';
import { FooterComponent } from './footer/footer.component';
import { PackageDetailComponent } from './package-detail/package-detail.component';
import { PackageEMIDetailComponent } from './package-emi-detail/package-emi-detail.component';
import { ContactUsComponent } from './contact-us/contact-us.component';

const routes: Routes = [
  {path:'',component: AboutUsComponent},
  {path:'main-menu', component: MainMenuComponent},
  {path:'about-us', component: AboutUsComponent},
  {path:'special',component:SpecialComponent},
  {path:'destination',component:DestinationComponent},
  {path:'package',component:PackageComponent},
  {path:'blog',component:BlogComponent},
  {path:'subscription',component:SubscriptionComponent},
  {path:'testmonial',component:TestmonialComponent},
  {path:'footer',component:FooterComponent},
  {path:'PackageDetail',component:PackageDetailComponent},
   {path:'package-emi-detail',component:PackageEMIDetailComponent},
   {path:'contact-us',component:ContactUsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponents=[MainMenuComponent,AboutUsComponent,SpecialComponent,DestinationComponent,PackageComponent,BlogComponent,SubscriptionComponent,TestmonialComponent,FooterComponent,PackageDetailComponent,PackageEMIDetailComponent,ContactUsComponent]