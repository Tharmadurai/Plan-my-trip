import { Component, OnInit } from '@angular/core';
//import { error } from 'util';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
declare const $;
window['$'] = window['jQuery'] = $;

@Component({
  selector: 'app-package',
  templateUrl: './package.component.html',
  styleUrls: ['./package.component.css']
})

export class PackageComponent implements OnInit {

  constructor() { 
  
    //console.log("Test");
    $(function () {
      //console.log("test ready");
      $('#first_click').on('click', function() {
        $(" .italy").modal("show");
      });
      $('#second_click').on('click',function(){
        $(" .england").modal("show")
      });
      $('#third_click').on('click',function(){
        $(" .france").modal("show")
      });
      $('#fourth_click').on('click',function(){
        $(" .india").modal("show")
      });
      $('#fifth_click').on('click',function(){
        $(" .spain").modal("show")
      });
      $('#sixth_click').on('click',function(){
        $(" .thailand").modal("show")
      });
    });
  }
  ngOnInit(): void {
  }

}
