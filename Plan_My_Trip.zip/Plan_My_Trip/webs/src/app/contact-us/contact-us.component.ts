import { Component, OnInit } from '@angular/core';
declare const $;
window['$'] = window['jQuery'] = $;
@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  constructor() { 
    $(document).ready(function(){
      $.validator.setDefaults({
         submitHandler:function(){
             alert("Your Message has been send.Thank you!");
         }
         });

         $("#frm").validate({
            rules:{
              name: "required",
              email:{
               required:true,
               email:true
              },
              subject:"required",
              message:"required"
            },
            messages:{
                 name:"please Enter Your Name",
                 email:{
                     required:"please Enter Your Email Id",
                     email:"Invalid Email Id",
                 },
                 subject:"Please Enter subject",
                 message:"please Enter Message!"
            }
         });
});   
  }

  ngOnInit(): void {
  }

}
