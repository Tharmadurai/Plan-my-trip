import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
@Component({
  selector: 'app-package-emi-detail',
  templateUrl: './package-emi-detail.component.html',
  styleUrls: ['./package-emi-detail.component.css']
})
export class PackageEMIDetailComponent implements OnInit{
  displayedColumns: string[] = ['PackageCost', 'packagename', 'emia', 'emib','emic'];
  dataSource = new MatTableDataSource<packageEmiDetail>(ELEMENT_DATA);

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }
}

export interface packageEmiDetail {
  PackageCost: number;
  packagename:string;
   emia: number;
   emib: number;
   emic: number;
}

const ELEMENT_DATA : packageEmiDetail[] = [
    {packagename: 'us',PackageCost:10000, emia:10000, emib: 10200, emic:10400},
    {packagename: 'uk', PackageCost:8000, emia:10200, emib: 10500, emic:10600},
    {packagename: 'us', PackageCost:12000, emia:10300, emib: 10600, emic:11200},
    {packagename: 'uk', PackageCost:10000, emia:10400, emib: 10800, emic:11200},
    {packagename: 'us', PackageCost:14000, emia:10600, emib: 11200, emic:11400},
    {packagename: 'uk', PackageCost:10000, emia:10800, emib: 11400, emic:11800},
    {packagename: 'us', PackageCost:15000, emia:11000, emib: 11200, emic:12000},
 ];
 /*displayedColumns: string[] = ['packagename', 'PackageCost', 'emia', 'emib','emic'];

  }*/


